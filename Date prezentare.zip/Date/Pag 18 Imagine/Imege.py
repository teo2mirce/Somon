from PIL import Image
import random



def drawImage(Name,A,B):
	testImage = Image.new("RGB", (600,440), (255,255,255))
	pixel = testImage.load()
	x=0
	y=0
	for r in range(A[0],B[0],2):
		for g in range(A[1],B[1],2):
			for b in range(A[2],B[2],2):
				pixel[x,y]=(r,g,b)
				x+=1
				if x==600:
					y+=1
					x=0
	testImage.save(Name+".jpg")

	
drawImage("B1",(0,0,0) , (128,128,128))
drawImage("B2",(0,0,128) , (128,128,255))
drawImage("B3",(0,128,0) , (128,255,128))
drawImage("B4",(0,128,128) , (128,255,255))
drawImage("B5",(128,0,0) , (255,128,128))
drawImage("B6",(128,0,128) , (255,128,255))
drawImage("B7",(128,128,0) , (255,255,128))
drawImage("B8",(128,128,128) , (255,255,255) )